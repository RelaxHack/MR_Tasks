#!/bin/bash
clear
choice_1="Please, enter <Name> <Surrname> <Phone#> : "
choice_2="Please, enter <Phone#> :  "
choice_3="Please, enter : <Name> <Surrname> "
choice_4="All records: "
press_enter="Press <enter> to continue "

IFS=$'\n'

choice=2
while [ $choice -ne 5 ]
do
echo " Menu: " ; echo " 1. Add record" ; echo " 2. Find record by phone" ; echo " 3. Find record by name" ;
 echo " 4. List records" ; echo " 5. Exit" ; echo "" ; echo -n "Your choice: " ; read choice ; clear
case "$choice" in
1) echo -n $choice_1 ; read answer ; echo $answer >> DB.txt ; echo $press_enter ; read ; clear;;
2) echo -n $choice_2 ; read answer ; echo "Items found: " ;
 awk -v input=$answer '{if(input==$3) print $1,$2}' DB.txt ; echo $press_enter ; read ; clear;;
3) echo -n $choice_3 ; read answer ; echo "Items found: " ;
 awk -v input=$answer '$0 ~ input {print $0}' DB.txt ; echo $press_enter ; read ; clear;;
4) echo $choice_4 ; cat DB.txt ; echo $press_enter ; read ; clear;;
esac
done
echo "Exit" ; echo $press_enter ; read ; clear
